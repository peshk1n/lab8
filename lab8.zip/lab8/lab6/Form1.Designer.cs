﻿namespace lab6
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.txtAngle = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.secondPointZ = new System.Windows.Forms.TextBox();
            this.secondPointY = new System.Windows.Forms.TextBox();
            this.secondPointX = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.firstPointZ = new System.Windows.Forms.TextBox();
            this.firstPointY = new System.Windows.Forms.TextBox();
            this.firstPointX = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.cbFlipYZ = new System.Windows.Forms.CheckBox();
            this.cbFlipXZ = new System.Windows.Forms.CheckBox();
            this.cbFlipXY = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtScaleZ = new System.Windows.Forms.TextBox();
            this.txtScaleY = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtScaleX = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtRotationZ = new System.Windows.Forms.TextBox();
            this.txtRotationY = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtRotationX = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtOffsetZ = new System.Windows.Forms.TextBox();
            this.txtOffsetY = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtOffsetX = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.create_fig = new System.Windows.Forms.Button();
            this.panel_points = new System.Windows.Forms.Panel();
            this.cnt_points = new System.Windows.Forms.TextBox();
            this.tbCnt = new System.Windows.Forms.TextBox();
            this.cbX = new System.Windows.Forms.CheckBox();
            this.cbY = new System.Windows.Forms.CheckBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.funcomboBox = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveTool = new System.Windows.Forms.ToolStripMenuItem();
            this.openTool = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.кубToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.икосаэдрToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.додекаэдрToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.октаэдрToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.тетраэдрToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.фигураВращенияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.графикToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.x_view = new System.Windows.Forms.TextBox();
            this.y_view = new System.Windows.Forms.TextBox();
            this.z_view = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.cameraX = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.cameraY = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.cameraZ = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.cameraX0 = new System.Windows.Forms.TextBox();
            this.cameraY0 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.camRot = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(0, 28);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(864, 662);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
            this.pictureBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseClick);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.txtAngle);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.secondPointZ);
            this.panel1.Controls.Add(this.secondPointY);
            this.panel1.Controls.Add(this.secondPointX);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.firstPointZ);
            this.panel1.Controls.Add(this.firstPointY);
            this.panel1.Controls.Add(this.firstPointX);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.cbFlipYZ);
            this.panel1.Controls.Add(this.cbFlipXZ);
            this.panel1.Controls.Add(this.cbFlipXY);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.txtScaleZ);
            this.panel1.Controls.Add(this.txtScaleY);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.txtScaleX);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.txtRotationZ);
            this.panel1.Controls.Add(this.txtRotationY);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.txtRotationX);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtOffsetZ);
            this.panel1.Controls.Add(this.txtOffsetY);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtOffsetX);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(664, 28);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 662);
            this.panel1.TabIndex = 1;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(22, 727);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(151, 28);
            this.comboBox1.TabIndex = 39;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // txtAngle
            // 
            this.txtAngle.Location = new System.Drawing.Point(61, 682);
            this.txtAngle.Name = "txtAngle";
            this.txtAngle.Size = new System.Drawing.Size(114, 27);
            this.txtAngle.TabIndex = 38;
            this.txtAngle.Text = "0";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(12, 685);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(44, 20);
            this.label19.TabIndex = 37;
            this.label19.Text = "Угол:";
            // 
            // secondPointZ
            // 
            this.secondPointZ.Location = new System.Drawing.Point(136, 640);
            this.secondPointZ.Name = "secondPointZ";
            this.secondPointZ.Size = new System.Drawing.Size(39, 27);
            this.secondPointZ.TabIndex = 36;
            // 
            // secondPointY
            // 
            this.secondPointY.Location = new System.Drawing.Point(93, 640);
            this.secondPointY.Name = "secondPointY";
            this.secondPointY.Size = new System.Drawing.Size(39, 27);
            this.secondPointY.TabIndex = 35;
            // 
            // secondPointX
            // 
            this.secondPointX.Location = new System.Drawing.Point(50, 640);
            this.secondPointX.Name = "secondPointX";
            this.secondPointX.Size = new System.Drawing.Size(39, 27);
            this.secondPointX.TabIndex = 34;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(14, 643);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 20);
            this.label18.TabIndex = 33;
            this.label18.Text = "p2:";
            // 
            // firstPointZ
            // 
            this.firstPointZ.Location = new System.Drawing.Point(136, 607);
            this.firstPointZ.Name = "firstPointZ";
            this.firstPointZ.Size = new System.Drawing.Size(39, 27);
            this.firstPointZ.TabIndex = 32;
            // 
            // firstPointY
            // 
            this.firstPointY.Location = new System.Drawing.Point(93, 607);
            this.firstPointY.Name = "firstPointY";
            this.firstPointY.Size = new System.Drawing.Size(39, 27);
            this.firstPointY.TabIndex = 31;
            // 
            // firstPointX
            // 
            this.firstPointX.Location = new System.Drawing.Point(50, 607);
            this.firstPointX.Name = "firstPointX";
            this.firstPointX.Size = new System.Drawing.Size(39, 27);
            this.firstPointX.TabIndex = 30;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(145, 583);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(18, 20);
            this.label17.TabIndex = 29;
            this.label17.Text = "Z";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(103, 583);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(17, 20);
            this.label16.TabIndex = 28;
            this.label16.Text = "Y";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(61, 583);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(18, 20);
            this.label15.TabIndex = 27;
            this.label15.Text = "X";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(14, 610);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 20);
            this.label14.TabIndex = 26;
            this.label14.Text = "p1:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(12, 550);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(179, 20);
            this.label13.TabIndex = 25;
            this.label13.Text = "Поворот вокруг прямой";
            // 
            // cbFlipYZ
            // 
            this.cbFlipYZ.AutoSize = true;
            this.cbFlipYZ.Location = new System.Drawing.Point(25, 499);
            this.cbFlipYZ.Name = "cbFlipYZ";
            this.cbFlipYZ.Size = new System.Drawing.Size(138, 24);
            this.cbFlipYZ.TabIndex = 23;
            this.cbFlipYZ.Text = "Отразить по YZ";
            this.cbFlipYZ.UseVisualStyleBackColor = true;
            this.cbFlipYZ.CheckedChanged += new System.EventHandler(this.cbFlipYZ_CheckedChanged);
            // 
            // cbFlipXZ
            // 
            this.cbFlipXZ.AutoSize = true;
            this.cbFlipXZ.Location = new System.Drawing.Point(25, 469);
            this.cbFlipXZ.Name = "cbFlipXZ";
            this.cbFlipXZ.Size = new System.Drawing.Size(139, 24);
            this.cbFlipXZ.TabIndex = 22;
            this.cbFlipXZ.Text = "Отразить по XZ";
            this.cbFlipXZ.UseVisualStyleBackColor = true;
            this.cbFlipXZ.CheckedChanged += new System.EventHandler(this.cbFlipXZ_CheckedChanged);
            // 
            // cbFlipXY
            // 
            this.cbFlipXY.AutoSize = true;
            this.cbFlipXY.Location = new System.Drawing.Point(25, 439);
            this.cbFlipXY.Name = "cbFlipXY";
            this.cbFlipXY.Size = new System.Drawing.Size(138, 24);
            this.cbFlipXY.TabIndex = 21;
            this.cbFlipXY.Text = "Отразить по XY";
            this.cbFlipXY.UseVisualStyleBackColor = true;
            this.cbFlipXY.CheckedChanged += new System.EventHandler(this.cbFlipXY_CheckedChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(25, 387);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(18, 20);
            this.label9.TabIndex = 20;
            this.label9.Text = "Z";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(25, 354);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(17, 20);
            this.label10.TabIndex = 19;
            this.label10.Text = "Y";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(25, 321);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(18, 20);
            this.label11.TabIndex = 18;
            this.label11.Text = "X";
            // 
            // txtScaleZ
            // 
            this.txtScaleZ.Location = new System.Drawing.Point(50, 384);
            this.txtScaleZ.Name = "txtScaleZ";
            this.txtScaleZ.Size = new System.Drawing.Size(125, 27);
            this.txtScaleZ.TabIndex = 17;
            this.txtScaleZ.Text = "1";
            // 
            // txtScaleY
            // 
            this.txtScaleY.Location = new System.Drawing.Point(50, 351);
            this.txtScaleY.Name = "txtScaleY";
            this.txtScaleY.Size = new System.Drawing.Size(125, 27);
            this.txtScaleY.TabIndex = 16;
            this.txtScaleY.Text = "1";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(14, 295);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(72, 20);
            this.label12.TabIndex = 15;
            this.label12.Text = "Масштаб";
            // 
            // txtScaleX
            // 
            this.txtScaleX.Location = new System.Drawing.Point(50, 318);
            this.txtScaleX.Name = "txtScaleX";
            this.txtScaleX.Size = new System.Drawing.Size(125, 27);
            this.txtScaleX.TabIndex = 14;
            this.txtScaleX.Text = "1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 248);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 20);
            this.label5.TabIndex = 13;
            this.label5.Text = "Z";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(25, 215);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(17, 20);
            this.label6.TabIndex = 12;
            this.label6.Text = "Y";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 182);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(18, 20);
            this.label7.TabIndex = 11;
            this.label7.Text = "X";
            // 
            // txtRotationZ
            // 
            this.txtRotationZ.Location = new System.Drawing.Point(50, 245);
            this.txtRotationZ.Name = "txtRotationZ";
            this.txtRotationZ.Size = new System.Drawing.Size(125, 27);
            this.txtRotationZ.TabIndex = 10;
            this.txtRotationZ.Text = "0";
            // 
            // txtRotationY
            // 
            this.txtRotationY.Location = new System.Drawing.Point(50, 212);
            this.txtRotationY.Name = "txtRotationY";
            this.txtRotationY.Size = new System.Drawing.Size(125, 27);
            this.txtRotationY.TabIndex = 9;
            this.txtRotationY.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(14, 156);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 20);
            this.label8.TabIndex = 8;
            this.label8.Text = "Поворот";
            // 
            // txtRotationX
            // 
            this.txtRotationX.Location = new System.Drawing.Point(50, 179);
            this.txtRotationX.Name = "txtRotationX";
            this.txtRotationX.Size = new System.Drawing.Size(125, 27);
            this.txtRotationX.TabIndex = 7;
            this.txtRotationX.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 113);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Z";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Y";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "X";
            // 
            // txtOffsetZ
            // 
            this.txtOffsetZ.Location = new System.Drawing.Point(50, 110);
            this.txtOffsetZ.Name = "txtOffsetZ";
            this.txtOffsetZ.Size = new System.Drawing.Size(125, 27);
            this.txtOffsetZ.TabIndex = 3;
            this.txtOffsetZ.Text = "0";
            // 
            // txtOffsetY
            // 
            this.txtOffsetY.Location = new System.Drawing.Point(50, 77);
            this.txtOffsetY.Name = "txtOffsetY";
            this.txtOffsetY.Size = new System.Drawing.Size(125, 27);
            this.txtOffsetY.TabIndex = 2;
            this.txtOffsetY.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Смещение";
            // 
            // txtOffsetX
            // 
            this.txtOffsetX.Location = new System.Drawing.Point(50, 44);
            this.txtOffsetX.Name = "txtOffsetX";
            this.txtOffsetX.Size = new System.Drawing.Size(125, 27);
            this.txtOffsetX.TabIndex = 0;
            this.txtOffsetX.Text = "0";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.create_fig);
            this.panel2.Controls.Add(this.panel_points);
            this.panel2.Controls.Add(this.cnt_points);
            this.panel2.Controls.Add(this.tbCnt);
            this.panel2.Controls.Add(this.cbX);
            this.panel2.Controls.Add(this.cbY);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Enabled = false;
            this.panel2.Location = new System.Drawing.Point(0, 27);
            this.panel2.Margin = new System.Windows.Forms.Padding(1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(186, 294);
            this.panel2.TabIndex = 40;
            this.panel2.Visible = false;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // create_fig
            // 
            this.create_fig.Location = new System.Drawing.Point(1, 262);
            this.create_fig.Margin = new System.Windows.Forms.Padding(1);
            this.create_fig.Name = "create_fig";
            this.create_fig.Size = new System.Drawing.Size(88, 28);
            this.create_fig.TabIndex = 0;
            this.create_fig.Text = "Построить";
            this.create_fig.UseVisualStyleBackColor = true;
            this.create_fig.Click += new System.EventHandler(this.create_fig_Click);
            // 
            // panel_points
            // 
            this.panel_points.Location = new System.Drawing.Point(0, 138);
            this.panel_points.Margin = new System.Windows.Forms.Padding(1);
            this.panel_points.Name = "panel_points";
            this.panel_points.Size = new System.Drawing.Size(152, 122);
            this.panel_points.TabIndex = 44;
            // 
            // cnt_points
            // 
            this.cnt_points.Location = new System.Drawing.Point(102, 112);
            this.cnt_points.Margin = new System.Windows.Forms.Padding(1);
            this.cnt_points.Name = "cnt_points";
            this.cnt_points.Size = new System.Drawing.Size(37, 27);
            this.cnt_points.TabIndex = 43;
            this.cnt_points.TextChanged += new System.EventHandler(this.cnt_points_TextChanged);
            // 
            // tbCnt
            // 
            this.tbCnt.Location = new System.Drawing.Point(6, 79);
            this.tbCnt.Margin = new System.Windows.Forms.Padding(1);
            this.tbCnt.Name = "tbCnt";
            this.tbCnt.Size = new System.Drawing.Size(120, 27);
            this.tbCnt.TabIndex = 42;
            this.tbCnt.Text = "20";
            // 
            // cbX
            // 
            this.cbX.AutoSize = true;
            this.cbX.Location = new System.Drawing.Point(6, 31);
            this.cbX.Margin = new System.Windows.Forms.Padding(1);
            this.cbX.Name = "cbX";
            this.cbX.Size = new System.Drawing.Size(40, 24);
            this.cbX.TabIndex = 40;
            this.cbX.Text = "X";
            this.cbX.UseVisualStyleBackColor = true;
            // 
            // cbY
            // 
            this.cbY.AutoSize = true;
            this.cbY.Checked = true;
            this.cbY.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbY.Location = new System.Drawing.Point(43, 31);
            this.cbY.Margin = new System.Windows.Forms.Padding(1);
            this.cbY.Name = "cbY";
            this.cbY.Size = new System.Drawing.Size(39, 24);
            this.cbY.TabIndex = 41;
            this.cbY.Text = "Y";
            this.cbY.UseVisualStyleBackColor = true;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(6, 109);
            this.label22.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(100, 20);
            this.label22.TabIndex = 2;
            this.label22.Text = "Образующая";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(6, 55);
            this.label21.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(139, 20);
            this.label21.TabIndex = 1;
            this.label21.Text = "Кол-во разбиений";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(6, 10);
            this.label20.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(110, 20);
            this.label20.TabIndex = 0;
            this.label20.Text = "Ось вращения";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label27);
            this.panel3.Controls.Add(this.textBox5);
            this.panel3.Controls.Add(this.funcomboBox);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.label26);
            this.panel3.Controls.Add(this.label25);
            this.panel3.Controls.Add(this.label24);
            this.panel3.Controls.Add(this.label23);
            this.panel3.Controls.Add(this.textBox4);
            this.panel3.Controls.Add(this.textBox3);
            this.panel3.Controls.Add(this.textBox2);
            this.panel3.Controls.Add(this.textBox1);
            this.panel3.Enabled = false;
            this.panel3.Location = new System.Drawing.Point(6, 325);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(252, 240);
            this.panel3.TabIndex = 41;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(6, 176);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(84, 20);
            this.label27.TabIndex = 12;
            this.label27.Text = "Разбиения";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(96, 172);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(65, 27);
            this.textBox5.TabIndex = 9;
            // 
            // funcomboBox
            // 
            this.funcomboBox.FormattingEnabled = true;
            this.funcomboBox.Location = new System.Drawing.Point(6, 3);
            this.funcomboBox.Name = "funcomboBox";
            this.funcomboBox.Size = new System.Drawing.Size(243, 28);
            this.funcomboBox.TabIndex = 10;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(3, 202);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(61, 29);
            this.button1.TabIndex = 11;
            this.button1.Text = "OK";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(14, 136);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(25, 20);
            this.label26.TabIndex = 8;
            this.label26.Text = "Y2";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(14, 103);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(25, 20);
            this.label25.TabIndex = 7;
            this.label25.Text = "Y1";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(14, 70);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(26, 20);
            this.label24.TabIndex = 6;
            this.label24.Text = "X2";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(13, 34);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(26, 20);
            this.label23.TabIndex = 5;
            this.label23.Text = "X1";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(96, 136);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(65, 27);
            this.textBox4.TabIndex = 4;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(96, 103);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(65, 27);
            this.textBox3.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(96, 70);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(65, 27);
            this.textBox2.TabIndex = 2;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(96, 37);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(65, 27);
            this.textBox1.TabIndex = 1;
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveTool,
            this.openTool});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(59, 24);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // saveTool
            // 
            this.saveTool.Name = "saveTool";
            this.saveTool.Size = new System.Drawing.Size(166, 26);
            this.saveTool.Text = "Сохранить";
            this.saveTool.Click += new System.EventHandler(this.saveTool_Click);
            // 
            // openTool
            // 
            this.openTool.Name = "openTool";
            this.openTool.Size = new System.Drawing.Size(166, 26);
            this.openTool.Text = "Открыть";
            this.openTool.Click += new System.EventHandler(this.openTool_Click);
            // 
            // добавитьToolStripMenuItem
            // 
            this.добавитьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.кубToolStripMenuItem,
            this.икосаэдрToolStripMenuItem,
            this.додекаэдрToolStripMenuItem,
            this.октаэдрToolStripMenuItem,
            this.тетраэдрToolStripMenuItem,
            this.фигураВращенияToolStripMenuItem,
            this.графикToolStripMenuItem});
            this.добавитьToolStripMenuItem.Name = "добавитьToolStripMenuItem";
            this.добавитьToolStripMenuItem.Size = new System.Drawing.Size(90, 24);
            this.добавитьToolStripMenuItem.Text = "Добавить";
            // 
            // кубToolStripMenuItem
            // 
            this.кубToolStripMenuItem.Name = "кубToolStripMenuItem";
            this.кубToolStripMenuItem.Size = new System.Drawing.Size(217, 26);
            this.кубToolStripMenuItem.Text = "Куб";
            this.кубToolStripMenuItem.Click += new System.EventHandler(this.кубToolStripMenuItem_Click);
            // 
            // икосаэдрToolStripMenuItem
            // 
            this.икосаэдрToolStripMenuItem.Name = "икосаэдрToolStripMenuItem";
            this.икосаэдрToolStripMenuItem.Size = new System.Drawing.Size(217, 26);
            this.икосаэдрToolStripMenuItem.Text = "Икосаэдр";
            this.икосаэдрToolStripMenuItem.Click += new System.EventHandler(this.икосаэдрToolStripMenuItem_Click);
            // 
            // додекаэдрToolStripMenuItem
            // 
            this.додекаэдрToolStripMenuItem.Name = "додекаэдрToolStripMenuItem";
            this.додекаэдрToolStripMenuItem.Size = new System.Drawing.Size(217, 26);
            this.додекаэдрToolStripMenuItem.Text = "Додекаэдр";
            this.додекаэдрToolStripMenuItem.Click += new System.EventHandler(this.додекаэдрToolStripMenuItem_Click);
            // 
            // октаэдрToolStripMenuItem
            // 
            this.октаэдрToolStripMenuItem.Name = "октаэдрToolStripMenuItem";
            this.октаэдрToolStripMenuItem.Size = new System.Drawing.Size(217, 26);
            this.октаэдрToolStripMenuItem.Text = "Октаэдр";
            this.октаэдрToolStripMenuItem.Click += new System.EventHandler(this.октаэдрToolStripMenuItem_Click);
            // 
            // тетраэдрToolStripMenuItem
            // 
            this.тетраэдрToolStripMenuItem.Name = "тетраэдрToolStripMenuItem";
            this.тетраэдрToolStripMenuItem.Size = new System.Drawing.Size(217, 26);
            this.тетраэдрToolStripMenuItem.Text = "Тетраэдр";
            this.тетраэдрToolStripMenuItem.Click += new System.EventHandler(this.тетраэдрToolStripMenuItem_Click);
            // 
            // фигураВращенияToolStripMenuItem
            // 
            this.фигураВращенияToolStripMenuItem.Name = "фигураВращенияToolStripMenuItem";
            this.фигураВращенияToolStripMenuItem.Size = new System.Drawing.Size(217, 26);
            this.фигураВращенияToolStripMenuItem.Text = "Фигура вращения";
            this.фигураВращенияToolStripMenuItem.Click += new System.EventHandler(this.фигураВращенияToolStripMenuItem_Click);
            // 
            // графикToolStripMenuItem
            // 
            this.графикToolStripMenuItem.Name = "графикToolStripMenuItem";
            this.графикToolStripMenuItem.Size = new System.Drawing.Size(217, 26);
            this.графикToolStripMenuItem.Text = "График";
            this.графикToolStripMenuItem.Click += new System.EventHandler(this.графикToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.добавитьToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(864, 28);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(6, 568);
            this.label28.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(112, 20);
            this.label28.TabIndex = 42;
            this.label28.Text = "Вектор обзора";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(6, 593);
            this.label29.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(18, 20);
            this.label29.TabIndex = 13;
            this.label29.Text = "X";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(72, 593);
            this.label30.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(17, 20);
            this.label30.TabIndex = 43;
            this.label30.Text = "Y";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(149, 593);
            this.label31.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(18, 20);
            this.label31.TabIndex = 44;
            this.label31.Text = "Z";
            this.label31.Click += new System.EventHandler(this.label31_Click);
            // 
            // x_view
            // 
            this.x_view.Location = new System.Drawing.Point(27, 593);
            this.x_view.Margin = new System.Windows.Forms.Padding(1);
            this.x_view.Name = "x_view";
            this.x_view.Size = new System.Drawing.Size(45, 27);
            this.x_view.TabIndex = 45;
            this.x_view.Text = "0";
            // 
            // y_view
            // 
            this.y_view.Location = new System.Drawing.Point(95, 593);
            this.y_view.Margin = new System.Windows.Forms.Padding(1);
            this.y_view.Name = "y_view";
            this.y_view.Size = new System.Drawing.Size(45, 27);
            this.y_view.TabIndex = 46;
            this.y_view.Text = "0";
            // 
            // z_view
            // 
            this.z_view.Location = new System.Drawing.Point(168, 593);
            this.z_view.Margin = new System.Windows.Forms.Padding(1);
            this.z_view.Name = "z_view";
            this.z_view.Size = new System.Drawing.Size(45, 27);
            this.z_view.TabIndex = 47;
            this.z_view.Text = "1";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(6, 621);
            this.label32.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(62, 20);
            this.label32.TabIndex = 48;
            this.label32.Text = "Камера";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(6, 652);
            this.label33.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(18, 20);
            this.label33.TabIndex = 49;
            this.label33.Text = "X";
            // 
            // cameraX
            // 
            this.cameraX.Location = new System.Drawing.Point(27, 649);
            this.cameraX.Margin = new System.Windows.Forms.Padding(1);
            this.cameraX.Name = "cameraX";
            this.cameraX.Size = new System.Drawing.Size(45, 27);
            this.cameraX.TabIndex = 50;
            this.cameraX.Text = "0";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(74, 652);
            this.label34.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(17, 20);
            this.label34.TabIndex = 51;
            this.label34.Text = "Y";
            // 
            // cameraY
            // 
            this.cameraY.Location = new System.Drawing.Point(95, 649);
            this.cameraY.Margin = new System.Windows.Forms.Padding(1);
            this.cameraY.Name = "cameraY";
            this.cameraY.Size = new System.Drawing.Size(45, 27);
            this.cameraY.TabIndex = 52;
            this.cameraY.Text = "0";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(149, 652);
            this.label35.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(18, 20);
            this.label35.TabIndex = 53;
            this.label35.Text = "Z";
            // 
            // cameraZ
            // 
            this.cameraZ.Location = new System.Drawing.Point(169, 649);
            this.cameraZ.Margin = new System.Windows.Forms.Padding(1);
            this.cameraZ.Name = "cameraZ";
            this.cameraZ.Size = new System.Drawing.Size(45, 27);
            this.cameraZ.TabIndex = 54;
            this.cameraZ.Text = "1";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(223, 652);
            this.label36.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(26, 20);
            this.label36.TabIndex = 55;
            this.label36.Text = "X0";
            // 
            // cameraX0
            // 
            this.cameraX0.Location = new System.Drawing.Point(260, 652);
            this.cameraX0.Margin = new System.Windows.Forms.Padding(1);
            this.cameraX0.Name = "cameraX0";
            this.cameraX0.Size = new System.Drawing.Size(45, 27);
            this.cameraX0.TabIndex = 56;
            this.cameraX0.Text = "0";
            // 
            // cameraY0
            // 
            this.cameraY0.Location = new System.Drawing.Point(353, 652);
            this.cameraY0.Margin = new System.Windows.Forms.Padding(1);
            this.cameraY0.Name = "cameraY0";
            this.cameraY0.Size = new System.Drawing.Size(45, 27);
            this.cameraY0.TabIndex = 57;
            this.cameraY0.Text = "0";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(326, 655);
            this.label37.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(25, 20);
            this.label37.TabIndex = 58;
            this.label37.Text = "Y0";
            // 
            // camRot
            // 
            this.camRot.Location = new System.Drawing.Point(420, 652);
            this.camRot.Margin = new System.Windows.Forms.Padding(1);
            this.camRot.Name = "camRot";
            this.camRot.Size = new System.Drawing.Size(45, 27);
            this.camRot.TabIndex = 59;
            this.camRot.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(864, 690);
            this.Controls.Add(this.camRot);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.cameraY0);
            this.Controls.Add(this.cameraX0);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.cameraZ);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.cameraY);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.cameraX);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.z_view);
            this.Controls.Add(this.y_view);
            this.Controls.Add(this.x_view);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Resize += new System.EventHandler(this.Form1_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox pictureBox1;
        private Panel panel1;
        private TextBox txtOffsetZ;
        private TextBox txtOffsetY;
        private Label label1;
        private TextBox txtOffsetX;
        private Label label2;
        private Label label4;
        private Label label3;
        private Label label9;
        private Label label10;
        private Label label11;
        private TextBox txtScaleZ;
        private TextBox txtScaleY;
        private Label label12;
        private TextBox txtScaleX;
        private Label label5;
        private Label label6;
        private Label label7;
        private TextBox txtRotationZ;
        private TextBox txtRotationY;
        private Label label8;
        private TextBox txtRotationX;
        private CheckBox cbFlipYZ;
        private CheckBox cbFlipXZ;
        private CheckBox cbFlipXY;
        private TextBox firstPointZ;
        private TextBox firstPointY;
        private TextBox firstPointX;
        private Label label17;
        private Label label16;
        private Label label15;
        private Label label14;
        private Label label13;
        private TextBox secondPointZ;
        private TextBox secondPointY;
        private TextBox secondPointX;
        private Label label18;
        private Label label19;
        private TextBox txtAngle;
        private ComboBox comboBox1;
        private Panel panel2;
        private TextBox tbCnt;
        private CheckBox cbX;
        private CheckBox cbY;
        private Label label22;
        private Label label21;
        private Label label20;
        private TextBox cnt_points;
        private Panel panel_points;
        private Button create_fig;
        private Panel panel3;
        private TextBox textBox1;
        private Label label26;
        private Label label25;
        private Label label24;
        private Label label23;
        private TextBox textBox4;
        private TextBox textBox3;
        private TextBox textBox2;
        private Button button1;
        private ComboBox funcomboBox;
        private Label label27;
        private TextBox textBox5;
        private ToolStripMenuItem файлToolStripMenuItem;
        private ToolStripMenuItem saveTool;
        private ToolStripMenuItem openTool;
        private ToolStripMenuItem добавитьToolStripMenuItem;
        private ToolStripMenuItem кубToolStripMenuItem;
        private ToolStripMenuItem икосаэдрToolStripMenuItem;
        private ToolStripMenuItem фигураВращенияToolStripMenuItem;
        private ToolStripMenuItem додекаэдрToolStripMenuItem;
        private ToolStripMenuItem графикToolStripMenuItem;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem октаэдрToolStripMenuItem;
        private ToolStripMenuItem тетраэдрToolStripMenuItem;
        private Label label28;
        private Label label29;
        private Label label30;
        private Label label31;
        private TextBox x_view;
        private TextBox y_view;
        private TextBox z_view;
        private Label label32;
        private Label label33;
        private TextBox cameraX;
        private Label label34;
        private TextBox cameraY;
        private Label label35;
        private TextBox cameraZ;
        private Label label36;
        private TextBox cameraX0;
        private TextBox cameraY0;
        private Label label37;
        private TextBox camRot;
    }
}